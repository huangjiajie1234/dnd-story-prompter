@echo off
cd /d %~dp0
echo 档案站：http://127.0.0.1:8765
where python >nul 2>nul && python -m http.server 8765 && goto :eof
where py >nul 2>nul && py -m http.server 8765 && goto :eof
npx --yes serve -p 8765

#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "档案站：http://127.0.0.1:8765"
if command -v python3 >/dev/null; then
  python3 -m http.server 8765
elif command -v python >/dev/null; then
  python -m http.server 8765
else
  npx --yes serve -p 8765
fi
